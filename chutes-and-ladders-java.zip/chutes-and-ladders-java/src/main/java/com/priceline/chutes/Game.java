package com.priceline.chutes;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.priceline.chutes.bean.Player;
import com.priceline.chutes.service.Board;
import com.priceline.chutes.service.GameImpl;

import lombok.SneakyThrows;

public class Game {

	
	private static final Logger LOGGER = Logger.getLogger(Game.class.getName());
	private static List<Player> players;
	private static final String N_VAL = "N";

	private static final String INPUT_PLAYER_INFO_MSG = " Enter Player Name & Age with ',' delimeter format e.g Anand Gupta,5. To Exit type 'n' and press enter to start the game!";

	
	public static void main(String[] args) {
		LOGGER.info("Initializing Chutes And Ladder Game...");

		try {
			inputPlayersInfo();
			Board service = Board.getInstance();
			// Instantiate GameImpl class providing its dependency class 'Board' as DI
			GameImpl gameImplementation = new GameImpl(service);
			Player winner = gameImplementation.playGame(players);
			LOGGER.info("The winner is: " + winner.getName());

		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured: " + e.getMessage());
		}
		
		LOGGER.info("Shutting Chutes And Ladder Game...");

	}
	

	/**
	 * Method to read Player input from console and build players list.
	 */
	@SneakyThrows()
	private static void inputPlayersInfo() {
		BufferedReader br = null;
		try {
            players = new ArrayList<>();
			br = new BufferedReader(new InputStreamReader(System.in)); 
	        String str = ""; 
	        System.out.println(INPUT_PLAYER_INFO_MSG);
	        while(!str.equalsIgnoreCase(N_VAL))
	        { 
				str = br.readLine(); 
				addPlayer(str);
	        } 
		}catch(Exception e) {
			LOGGER.log(Level.SEVERE, "Exception occured while accepting input Player information : " + e.getMessage());
			throw e;
		}finally {
			if(br!=null) {
				br.close();
			}
		}
		
	}

	/**
	 * Method to create Player object and add into list.
	 * @param str - Player info
	 */
	private static void addPlayer(String str) {
		if (!str.isEmpty() && !str.equalsIgnoreCase(N_VAL)) {
			if (str.contains(",")) {
				String player[] = str.split(",");
				Player playerObj = null;
				try {
					playerObj = new Player(player[0], Integer.parseInt(player[1]));
				} catch (NumberFormatException e) {
					LOGGER.log(Level.SEVERE, "Entered Player Age must be number !! " + INPUT_PLAYER_INFO_MSG);
				}
				if (playerObj != null) {
					players.add(playerObj);
				}
			} else {
				LOGGER.log(Level.SEVERE, "Invalid Data Format!! " + INPUT_PLAYER_INFO_MSG);
			}
		}
	}
			
}
