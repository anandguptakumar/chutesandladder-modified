package com.priceline.chutes.exception;

/**
* <h1> Custom Player Not Allowed Exception class</h1>
* The <code>PlayerNotAllowedException.java</code> program will be used to throw exception
* if player's age is not within allowed age range.
*
* @author  Anand Gupta
* @version 0.1
*/

public class PlayerNotAllowedException extends RuntimeException {

    private static final long serialVersionUID = 1L;
	
  
    public PlayerNotAllowedException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public PlayerNotAllowedException(final String message) {
        super(message);
    }

}