package com.priceline.chutes.service;


import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.priceline.chutes.bean.BoardSquare;

import static java.util.Map.entry;
/**
* This singleton Board class is used to define Chutes And Ladders Game board like special squares
* with chute and ladder locations.
* @author  Anand Gupta
* @version 0.1
*/

public class Board {

	private static Board BOARD_SINGLETON_INSTANCE = null;
	
	private static List<BoardSquare> squares;
	
    // Making constructor of Board class private
    private Board() {

        squares = java.util.stream.IntStream.rangeClosed(1, 100)
                .mapToObj(i -> Optional
                        .ofNullable(specialSquares.get(i))
                        .orElseGet(BoardSquare::new))
                .collect(Collectors.toList());
    }
    
	/**
	 * Method to return single instance of Board class, this takes care of the lazy instantiation
	 * means this Board class defining game board like chute and ladder locations will be initialized
	 * when Game application is initialized and guaranteed to be thread safe.
	 * @return Board
	 */
	public static Board getInstance() {
		if (BOARD_SINGLETON_INSTANCE == null) {
			synchronized (Board.class) {
				if (BOARD_SINGLETON_INSTANCE == null) {					
					BOARD_SINGLETON_INSTANCE = new Board();

				}
			}
		}
		return BOARD_SINGLETON_INSTANCE;
	}
	
	/**
	 * This method is called immediately after an object of this class is de-serialized.
	 * @return Same singleton object reference for Board class 
	 */	
	protected Object readResolve() {
	   // Instead of the object were on, return the class variable singleton
	   return BOARD_SINGLETON_INSTANCE;
	}

	/**
	 * Method to return BoardSquare object based on provided index from the 'squares' list.
	 * @param i - index
	 * @return BoardSquare
	 */
	public BoardSquare getSquareAtPosition(int i){
        return squares.get(i-1);
    }

	private static final Map<Integer, BoardSquare> specialSquares = Map.ofEntries(
            entry(1, new BoardSquare(false, true, 37)),
            entry(4, new BoardSquare(false, true, 10)),
            entry(9, new BoardSquare(false, true, 22)),
            entry(16, new BoardSquare(true, false, 10)),
            entry(21, new BoardSquare(false, true, 21)),
            entry(28, new BoardSquare(false, true, 56)),
            entry(36, new BoardSquare(false, true, 8)),
            entry(47, new BoardSquare(true, false, 21)),
            entry(49, new BoardSquare(true, false, 38)),
            entry(51, new BoardSquare(false, true, 16)),
            entry(56, new BoardSquare(true, false, 3)),
            entry(62, new BoardSquare(true, false, 43)),
            entry(64, new BoardSquare(true, false, 4)),
            entry(71, new BoardSquare(false, true, 20)),
            entry(80, new BoardSquare(false, true, 20)),
            entry(87, new BoardSquare(true, false, 63)),
            entry (93, new BoardSquare(true, false, 20)),
            entry(95, new BoardSquare(true, false, 20)),
            entry(98, new BoardSquare(true, false, 20))
    );
}
