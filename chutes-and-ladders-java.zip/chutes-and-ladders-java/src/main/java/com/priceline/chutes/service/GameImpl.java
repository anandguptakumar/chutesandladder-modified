package com.priceline.chutes.service;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;

import com.priceline.chutes.bean.BoardSquare;
import com.priceline.chutes.bean.Player;
import com.priceline.chutes.exception.PlayerInvalidCountException;
import com.priceline.chutes.util.ChutesAndLadderGameUtility;

import lombok.SneakyThrows;

/**
* <h1>Service Implementation for Chutes And Ladder Game functionality.</h1>
* The <code>GameImpl.java</code> program implements operations for <code>IGame.java</code>
* for playing Chutes And Ladder game.
*
* @author  Anand Gupta
* @version 0.1
*/

public class GameImpl implements IGame {

	private static final int WINNING_SQUARE_POS = 100;

	Board board;
    // Parameterized constructor passing dependent 'Board' object as constructor-arg
    public GameImpl(Board board) {
        this.board = board;
    }
    
	@Override
	public Player playGame(final List<Player> players) throws PlayerInvalidCountException {
		
		// perform check whether required number of players provided to play the game
		validatePlayersSize(players);
		
		while(true){			
	        for (Player currentPlayer : players) {
	            int spinResult = spin();
	            int nextPosition = currentPlayer.getPosition() + spinResult;
	            if (nextPosition > WINNING_SQUARE_POS){
	                break;
	            }
	            BoardSquare nextSquare = board.getSquareAtPosition(nextPosition);
	            nextPosition += ChutesAndLadderGameUtility.getNumberSquaresToSkip(nextSquare);
	            if (nextPosition < WINNING_SQUARE_POS) {
	                currentPlayer.setPosition(nextPosition);
	            } else if (nextPosition == WINNING_SQUARE_POS) {
	                return currentPlayer; //The winner!
	            }
	        }
	    }
	}
	
	/**
	 * Method to validate input players list for NULL or valid size between 2-4 players
	 * required to play the game.
	 * @return void
	 * @throws PlayerInvalidCountException
	 */
	@SneakyThrows(PlayerInvalidCountException.class)
	private void validatePlayersSize(final List<Player> players){
		if (Objects.isNull(players) || (players.size() < 2)) {
			throw new PlayerInvalidCountException("You require at least 2 players to play this game.");
		}
		if (players.size() > 4) {
			throw new PlayerInvalidCountException("Number of Players exceeded than max 4 allowed players.");
		} 
	}
	
	/**
	 * Method to mock spinner and return random spin number.
	 * @return int - random spin number
	 */
	private int spin(){
		// Instead of Random used ThreadLocalRandom for better efficiency with no contention in multi-threaded env
		return ThreadLocalRandom.current().nextInt(1, 6) + 1; 
	}
}


