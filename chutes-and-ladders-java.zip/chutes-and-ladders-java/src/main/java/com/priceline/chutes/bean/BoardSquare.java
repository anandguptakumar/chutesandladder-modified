package com.priceline.chutes.bean;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
* This POJO class represents BoardSquare for holding BoardSquare's attribute info.
* @author  Anand Gupta
* @version 0.1
*/
@Getter
@Setter(AccessLevel.NONE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BoardSquare {
	
    private boolean isChute;
    private boolean isLadder;
    private int numberSquaresToSkip;

}
