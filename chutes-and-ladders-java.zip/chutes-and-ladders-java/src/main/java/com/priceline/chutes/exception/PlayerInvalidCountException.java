package com.priceline.chutes.exception;

/**
* <h1> Custom Player Invalid Count Exception class</h1>
* The <code>PlayerInvalidCountException.java</code> program will be used to throw exception
* there are insufficient count of players.
*
* @author  Anand Gupta
* @version 0.1
*/

public class PlayerInvalidCountException extends Exception {

    private static final long serialVersionUID = 1L;
	
  
    public PlayerInvalidCountException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public PlayerInvalidCountException(final String message) {
        super(message);
    }

}