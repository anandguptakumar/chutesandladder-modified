package com.priceline.chutes.bean;

import com.priceline.chutes.exception.PlayerNotAllowedException;

import lombok.Data;
import lombok.NonNull;
import lombok.ToString;


/**
* This POJO class represents player for holding player's information like name, age,
* current position of player in the game. 
* @author  Anand Gupta
* @version 0.1
*/
@Data
@ToString
public class Player {
	
    @NonNull
    private String name;    
    @NonNull
    private Integer age;
    private int position;
    
    /**
	 * Parameterized constructor to initialize Player object using name and age attributes.
	 * 
	 * @param name
	 * @param age
	 * 
	 * @throws PlayerNotAllowedException if player's age is either
	 * less than 4 years or greater than 7 years.
	 */
	public Player(String name, int age) {
		if (age < 4 || age > 7) {
			throw new PlayerNotAllowedException(String
					.format("Input player ' %s ' cannot play this game as it is currently"
							+ " designed only for [4 to 7] years age group", name));
		}
		this.name = name;
		this.age = age;
		this.position = 0;
	}
}