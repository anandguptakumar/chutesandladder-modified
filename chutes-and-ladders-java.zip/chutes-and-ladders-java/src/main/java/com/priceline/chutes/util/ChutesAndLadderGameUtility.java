package com.priceline.chutes.util;

import com.priceline.chutes.bean.BoardSquare;

/**
 * A utility class for Chutes And Ladder game.
 * @author  Anand Gupta
 * @version 0.1
 */

public final class ChutesAndLadderGameUtility { 

    /**
     * This class should not be instantiated.
     */
    private ChutesAndLadderGameUtility() { }

    /**
     * Utility method to get number of squares blocks to be skipped or moved based on
     * whether its chute or ladder. 
     * @param boardSquare object of BoardSquare type
     * @return int - no of squares to be skipped
     */
    public static final int getNumberSquaresToSkip(BoardSquare boardSquare) {
    	
        if (boardSquare.isLadder()) {
            return boardSquare.getNumberSquaresToSkip();
        } else if (boardSquare.isChute()) {
            return boardSquare.getNumberSquaresToSkip() * -1;
        } else {
            return 0;
        }
    }
  
}