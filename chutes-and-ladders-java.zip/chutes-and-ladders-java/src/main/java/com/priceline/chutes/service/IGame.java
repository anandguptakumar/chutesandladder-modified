package com.priceline.chutes.service;

import java.util.List;

import com.priceline.chutes.bean.Player;
import com.priceline.chutes.exception.PlayerInvalidCountException;

/**
* <h1>Game Interface for defining operations for Chutes And Ladder functionality.</h1>
* The <code>IGame.java</code> program defines operations for playing Chutes And Ladder game.
*
* @author  Anand Gupta
* @version 0.1
*/
public interface IGame {

	/**
	 * Method to play Chutes And Ladder game with provided list of Players.
	 * 
	 * @param players - List of players
	 * @return Player object - winner
	 * @throws PlayerInvalidCountException
	 */
	Player playGame(final List<Player> players) throws PlayerInvalidCountException;
}


