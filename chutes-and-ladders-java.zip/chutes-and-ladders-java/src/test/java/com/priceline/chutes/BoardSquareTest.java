package com.priceline.chutes;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import com.priceline.chutes.bean.BoardSquare;
import com.priceline.chutes.util.ChutesAndLadderGameUtility;

public class BoardSquareTest {

    @Test
    public void aChuteShouldSkipSquaresReversed(){
        BoardSquare square = new BoardSquare(true, false, 10);
        assertTrue(ChutesAndLadderGameUtility.getNumberSquaresToSkip(square) < 0);
    }
}
